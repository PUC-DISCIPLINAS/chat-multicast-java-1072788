package redes;

import java.net.*;
import java.util.Scanner;

import multicast.MulticastPeer;

import java.io.*;

public class TCPClient {
	public static void main(String args[]) {
		// arguments supply message and hostname
		Socket s = null;
		try {
			int serverPort = 7896;
			InetAddress ip = InetAddress.getLocalHost();
			String hostname = ip.getHostName();
			s = new Socket(hostname, serverPort);
            System.out.println("Your current IP address : " + hostname);
            
            Scanner read = new Scanner(System.in);
            String op;
    		Boolean option = false;
    		while(!option) {
    			System.out.println("Chat2 - Trabalho 1 \n"
    					+ "1) Ver salas; \n"
    					+ "2) Criar sala; \n"
    					+ "3) Entrar na sala; \n"
    					+ "0) Fechar aplica��o \n"
    					);
    		
    			
    			System.out.printf("Informe a op��o: ");
    			
    			op = read.nextLine(); 
    			System.out.printf(op);
    			
    			if (op.equalsIgnoreCase("0")) {
    				option = true;
    			}
    			
    			else if(op.equalsIgnoreCase("1")) {
        			//enviar mensagem
    				DataOutputStream out = new DataOutputStream(s.getOutputStream());
    				out.writeUTF("!ver");
    				
    				//receber mensagem 
    				DataInputStream in = new DataInputStream(s.getInputStream());
    				String data = in.readUTF(); // � uma linha do fluxo de dados
    				System.out.println("\nSalas dispon�veis: " + data);
    			}

    			else if(op.equalsIgnoreCase("2")) {
    				System.out.printf("\nDigite o nome da sala: ");
        			op = read.nextLine();
        			System.out.print(op);
        			
        			//enviar mensagem
    				DataOutputStream out = new DataOutputStream(s.getOutputStream());
    				out.writeUTF("!criar@"+op);
    				
    				//receber mensagem 
    				DataInputStream in = new DataInputStream(s.getInputStream());
    				String data = in.readUTF(); // � uma linha do fluxo de dados
    				System.out.println(data);
    				
    			}
    			
    			else if(op.equalsIgnoreCase("3")) {
    				
    				System.out.printf("Digite o nome da sala que deseja entrar: ");
        			op = read.nextLine();
        			System.out.print(op);
        			
        			//enviar mensagem para o servidor
    				DataOutputStream out = new DataOutputStream(s.getOutputStream());
    				out.writeUTF("!entrar@"+op);
    				
    				//receber mensagem 
    				DataInputStream in = new DataInputStream(s.getInputStream());
    				String data = in.readUTF(); // � uma linha do fluxo de dados
    				//System.out.println(data);
    				
    				//Entrar na sala
    				MulticastPeer mp = new MulticastPeer(serverPort, data);
    				mp.joinChat();
    				mp.start();    				
    				Boolean start = true;
    				while(start) {
    					System.out.printf("Digite a mensagem: ");
            			op = read.nextLine();
            			System.out.print(op);
            			
            			DataOutputStream outMsg = new DataOutputStream(s.getOutputStream());
            			
            			if(op.equalsIgnoreCase("!sair")) {
            				start=false;
        					outMsg.writeUTF("!sair@"+op);
        					mp.stopListening();
        					mp.leaveChat();
        					
        					}
            			else {
            				mp.sendMsg("Amanda", op);
            				//outMsg.writeUTF("!msg@"+op);
            			}

    				}
    				
    			}

    		}
    		read.close();
    		s.close();
		} catch (UnknownHostException e) {
			System.out.println("Socket:" + e.getMessage());
		} catch (EOFException e) {
			System.out.println("EOF:" + e.getMessage());
		} catch (IOException e) {
			System.out.println("readline:" + e.getMessage());
		} finally {
			if (s != null)
				try {
					s.close();
				} catch (IOException e) {
					System.out.println("close:" + e.getMessage());
				}
		}
	}
}


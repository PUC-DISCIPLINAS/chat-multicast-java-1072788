package multicast;

import java.net.*;
import java.io.*;

public class MulticastPeer extends Thread {
	private volatile boolean isRunning = true;
	private MulticastSocket mSocket = null;
	private InetAddress groupIp = null;
	public int socket = 0;
	
	public MulticastPeer(int socket, String groupIp) {
		
		try {
			this.socket = socket; 
			this.groupIp =  InetAddress.getByName(groupIp);
			this.mSocket = new MulticastSocket(this.socket);
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		}
	}
	
	public void joinChat() {
		try {
			this.mSocket.joinGroup(this.groupIp);
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		}
	}
	
	public void leaveChat() {
		try {
			this.mSocket.leaveGroup(this.groupIp);
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		}
	}
	
	public void sendMsg(String user, String txt) {
		String msg = new String(user+": "+txt);
		System.out.println("sendmsg");
		byte[] message = msg.getBytes();
		DatagramPacket messageOut = new DatagramPacket(message, message.length, this.groupIp, this.socket);
		try {
			this.mSocket.send(messageOut);
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		}		
	}
	
	public void run() {
		byte[] buffer = new byte[1000];
		while(this.isRunning) {
			//Receber mensagem do grupo
			DatagramPacket messageIn = new DatagramPacket(buffer, buffer.length);
			try {
				this.mSocket.receive(messageIn);
			} catch (IOException e) {
				System.out.println("IO: " + e.getMessage());
			}
			System.out.println(new String(messageIn.getData()).trim());
			buffer = new byte[1000];
		}
		
	}
	
	public void stopListening() {
		this.isRunning = false;
	}
	
	
}
